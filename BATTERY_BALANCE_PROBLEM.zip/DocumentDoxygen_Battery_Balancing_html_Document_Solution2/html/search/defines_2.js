var searchData=
[
  ['max_5fbatt_5fvol_21',['max_batt_vol',['../_cell___balance__solution2_8cpp.html#aacbaee63c18f9f0024974d0d8bae26da',1,'Cell_Balance_solution2.cpp']]],
  ['min_5flimit_22',['min_limit',['../_cell___balance__solution2_8cpp.html#aea5311f0e3e86a232370c25c77f6e320',1,'Cell_Balance_solution2.cpp']]]
];
