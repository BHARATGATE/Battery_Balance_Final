var searchData=
[
  ['max_5fbatt_5fvol_28',['max_batt_vol',['../_cell___balance_01_072_08_8cpp.html#aacbaee63c18f9f0024974d0d8bae26da',1,'max_batt_vol():&#160;Cell_Balance (2).cpp'],['../_cell___balance_01_073_08_8cpp.html#aacbaee63c18f9f0024974d0d8bae26da',1,'max_batt_vol():&#160;Cell_Balance (3).cpp'],['../_cell___balance__solution1_8cpp.html#aacbaee63c18f9f0024974d0d8bae26da',1,'max_batt_vol():&#160;Cell_Balance_solution1.cpp']]],
  ['min_5flimit_29',['min_limit',['../_cell___balance_01_072_08_8cpp.html#aea5311f0e3e86a232370c25c77f6e320',1,'min_limit():&#160;Cell_Balance (2).cpp'],['../_cell___balance_01_073_08_8cpp.html#aea5311f0e3e86a232370c25c77f6e320',1,'min_limit():&#160;Cell_Balance (3).cpp'],['../_cell___balance__solution1_8cpp.html#aea5311f0e3e86a232370c25c77f6e320',1,'min_limit():&#160;Cell_Balance_solution1.cpp']]]
];
